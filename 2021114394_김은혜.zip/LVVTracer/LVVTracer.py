from sha256 import generate_hash
from md5 import md5_me
import hashlib
import doctest
import unittest
import inspect
import sys
from types import FrameType, TracebackType
from typing import Any, Optional, Callable, Dict, List, Type, TextIO, cast
from collections.abc import Generator
from math import sin

counters = {
    'generate_hash' : 0,
    'md5_me' : 0
}

def print_counters():
    global counters
    for func_name, count in counters.items():
        print(f"{func_name}: {count}")
        
class LVVTracer():
    def __init__(self, file:TextIO = sys.stdout) -> Dict:
        self.last_vars: Dict[str, Any] = {}
           
    def __enter__(self) -> Any:
        self.original_trace_function = sys.gettrace()
        sys.settrace(self._traceit)
        return self
    
    def __exit__(self, exc_tp: Type, exc_value:BaseException, exc_traceback:TracebackType) -> Optional[bool]:
        sys.settrace(self.original_trace_function)
        if self.is_internal_error(exc_tp, exc_value, exc_traceback):
            return False
        else:
            return None
    
    def getLVVmap(self, new_vars:Dict[str, Any]) -> Dict[str, Any]:
        changed = {}
        for var_name, var_value in new_vars.items():
            if (var_name not in self.last_vars or self.last_vars[var_name] != var_value):
                changed[var_name] = var_value
        self.last_vars = new_vars.copy()
        return changed
    
    def test_lvv_sha256():
        with LVVTracer(target_func = "generate_hash") as traced:
            encoded = "mysalt".encode()
            generate_hash(encoded).hex()

        answer = {'t': 128, 'message_schedule': 65, 'a': 65, 'b': 65, 'c': 65, 'd': 65, 'e': 65, 'f': 65, 'g': 65, 'h': 65, 't1': 64, 't2': 64, 'message': 52, 'term1': 48, 'schedule': 48, 'term2': 43, 'term3': 36, 'term4': 36, 'blocks': 2, 'h0': 2, 'h1': 2, 'h2': 2, 'h3': 2, 'h5': 2, 'h4': 2, 'h6': 2, 'h7': 2, 'length': 1, 'i': 1, 'message_block': 1}
        assert traced.getLVVmap() == answer

    def test_lvv_md5():
        with LVVTracer(target_func = "md5_me") as traced:
            encoded = "mypepperoni".encode()
            md5_me(encoded).hex()

        answer = {'f': 128, 'a': 65, 'b': 65, 'c': 65, 'd': 65, 'i': 64, 'g': 64, 'a0': 2, 'b0': 2, 'c0': 2, 'd0': 2, 'message': 1, 'bit_string': 1, 'added_consts': 1, 'shift_amounts': 1, 'block_words': 1, 'digest': 1}
        assert traced.getLVVmap() == answer
        
def count_changes(original_str, modified_str):
    count_dict = {}
    for algorithm in ['md5', 'sha1', 'sha256']:
        hash_func = getattr(hashlib, algorithm)
        original_hash = hash_func(original_str.encode()).hexdigest()
        modified_hash = hash_func(modified_str.encode()).hexdigest()
        count = 0
        for i in range(len(original_hash)):
            if original_hash[i] != modified_hash[i]:
                count += 1
        count_dict[algorithm] = count
    return count_dict

original_str = "Hello, world!"
modified_str = "Hello, world!!"
count_dict = count_changes(original_str, modified_str)
print(count_dict)